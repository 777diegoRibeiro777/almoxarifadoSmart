import axios from "axios";

export const API = axios.create({
  baseURL: "http://3.145.53.73:8010/api",
});
//https://localhost:7076/api
